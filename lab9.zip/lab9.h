//------------------------------------------------------------------------------
// h file for Lab 9
//------------------------------------------------------------------------------
#pragma once

#define NUM_LETTERS			26
#define ASCII_LOWERCASE_A	97

#define MAX_A				20

// local function prototypes
void get_letters(char b[]);
void display_words(char b[]);
void count_letters(char b[]);

