//------------------------------------------------------------------------------
// lab9.cpp
//
// Fills a char array with lowercase letters a - z
// Displays the array as four-letter words
// Counts occurrences of each letter in the array
//------------------------------------------------------------------------------

#include <iostream>
#include <string>
#include <ctime>

#include "lab9.h"

int main()
{
	int i = 0;

	char a[MAX_A];

	// seed the random number gen
	srand(time(0));	

	// fill the array with random letters
	get_letters(a);

	// display four-letter words
	display_words(a);

	// count the occurrences of each letter
	count_letters(a);

	std::cout << std::endl;

	system("pause");

	return 0;
}
