//------------------------------------------------------------------------------
// lab9_funcs.cpp
//
// Functions for lab9.cpp
//------------------------------------------------------------------------------
#include <iostream>
#include <string>
#include <ctime>

#include "lab9.h"

//------------------------------------------------------------------------------
// fill a character array with random letters
//------------------------------------------------------------------------------
void get_letters(char b[])
{
	for (unsigned i = 0; i < MAX_A; i++)
	{
		// get a random number between 0 and 25 and convert to a lowercase letter
		int x = rand() % NUM_LETTERS + 'a';

		b[i] = (char)x;
	}
}

//------------------------------------------------------------------------------
// display letters
//------------------------------------------------------------------------------
void display_words(char b[])
{
	//0000 - 1111  unsigned:  interpreted as 0 to 15
	//0000 - 1111  int interpreted as -8 to 7

	unsigned index = 0;
	int j = 0;

	for (unsigned i = 0; i < MAX_A; i++)
	{
		std::cout << b[i];

		index++;
		//		if (index == 4)
		if (index % 4 == 0)
		{
			std::cout << " ";
			index = 0;
		}

	}

	std::cout << std::endl;

	//if ((i > 0) && (i % 4 == 0))
	//	std::cout << " ";
}

//------------------------------------------------------------------------------
// count letter occurrences in an array of char
//------------------------------------------------------------------------------
void count_letters(char b[])
{
	for (int i = 0; i < NUM_LETTERS; i++)
	{
		int count = 0;
		int letter = i + ASCII_LOWERCASE_A;

		for (int k = 0; k < 20; k++)
		{
			if (b[k] == letter)
				count++;
		}

		if (count != 0)
			std::cout << "there are " << count << " "
			<< (char)letter << "'s" << std::endl;

		letter++;

	}

}


//------------------------------------------------------------------------------
// get a random int #TODO
//------------------------------------------------------------------------------
int get_random_int()
{
	return 1;
}

